<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../services/AutomationEngine.php';

class Lot {
    private $db;

    // Reentrancy guard for syncExpiredLots() (Batch L2.5) — see that
    // method's comment for why this is needed: it now calls
    // AutomationEngine::run(), whose apply/validate closures call
    // $this->findById()/$this->transitionStatus(), both of which call
    // $this->syncExpiredLots() again at their own top. Without this flag,
    // that would recurse forever on the very first candidate lot.
    private $syncingExpiredLots = false;

    public function __construct() {
        $this->db = Database::getInstance()->getConnection();
    }

    // Follows the same "sync lazily on read" convention already used by
    // ReportController::occupancy() for occupancy_snapshots (see docs/database.md)
    // rather than a cron job, since this app has no scheduler set up. Only flips
    // Occupied lots whose latest expiration_records lease has lapsed and was
    // never marked renewed. Deliberately excludes Reserved: a lot can be
    // rebooked after being freed (manually reset from Expired to Available,
    // then re-confirmed), and during the window between that re-confirmation
    // and the new burial's completion the "latest" expiration record on file is
    // still the *previous* tenant's — touching Reserved here would wrongly
    // re-expire a lot that's actively being booked again. ScheduleController's
    // createLeaseRecordIfMissing() keys its own dedupe on (lot_id, start_date)
    // for the same reason, so a genuinely new occupancy always gets its own
    // fresh record once it completes.
    //
    // Batch L2.5: the actual status write moved off a raw, unaudited
    // UPDATE ... JOIN and onto the same AutomationEngine::run() ->
    // Lot::transitionStatus() envelope every other lifecycle transition in
    // this app already uses — this SELECT only identifies candidates, exact
    // same join/conditions as the old raw UPDATE's WHERE clause, nothing
    // about eligibility changed. Idempotent by construction: once a
    // candidate's transitionStatus() call succeeds, its status is no
    // longer 'Occupied', so it can never match this SELECT again on a
    // later call — no separate dedupe mechanism needed. The actor is
    // deliberately null (system-triggered, not a logged-in user) — the
    // exact same pattern AutomationEngine::run() already supports (its
    // actorId resolution is null-safe for a non-array actor).
    private function syncExpiredLots() {
        if ($this->syncingExpiredLots) {
            return;
        }
        $this->syncingExpiredLots = true;
        try {
            $stmt = $this->db->query("
                SELECT l.lot_id
                FROM lots l
                JOIN (
                    SELECT er.lot_id, er.end_date, er.renewed
                    FROM expiration_records er
                    INNER JOIN (
                        SELECT lot_id, MAX(expiration_id) AS max_id
                        FROM expiration_records
                        GROUP BY lot_id
                    ) latest ON latest.lot_id = er.lot_id AND latest.max_id = er.expiration_id
                ) e ON e.lot_id = l.lot_id
                WHERE e.renewed = 'no'
                  AND e.end_date < CURDATE()
                  AND l.status = 'Occupied'
            ");
            $candidateLotIds = $stmt->fetchAll(PDO::FETCH_COLUMN);

            foreach ($candidateLotIds as $lotId) {
                $lotId = (int) $lotId;
                AutomationEngine::run(
                    'lot.expired',
                    'Lot',
                    $lotId,
                    null,
                    function () use ($lotId) {
                        $current = $this->findById($lotId);
                        if (!$current) {
                            return ['Lot no longer exists'];
                        }
                        if ($current['status'] !== 'Occupied') {
                            return ['Lot ' . ($current['lot_number'] ?? $lotId) . ' is no longer Occupied (current: ' . $current['status'] . ') — expiration no longer applies'];
                        }
                        return true;
                    },
                    function () use ($lotId) {
                        return $this->transitionStatus($lotId, 'Expired', self::allowedFromStatusesFor('lot.expired', 'Expired'));
                    }
                );
            }
        } finally {
            $this->syncingExpiredLots = false;
        }
    }

    private function applyFilters(&$sql, &$params, $filters) {
        if (!empty($filters['section'])) {
            $sql .= " AND s.section_name = ?";
            $params[] = $filters['section'];
        }
        if (!empty($filters['lot_number'])) {
            $sql .= " AND l.lot_number LIKE ?";
            $params[] = '%' . $filters['lot_number'] . '%';
        }
        if (!empty($filters['lot_type'])) {
            $sql .= " AND t.type_name = ?";
            $params[] = $filters['lot_type'];
        }
        if (!empty($filters['min_price'])) {
            $sql .= " AND l.price >= ?";
            $params[] = (float) $filters['min_price'];
        }
        if (!empty($filters['max_price'])) {
            $sql .= " AND l.price <= ?";
            $params[] = (float) $filters['max_price'];
        }
        if (!empty($filters['status'])) {
            $sql .= " AND l.status = ?";
            $params[] = $filters['status'];
        }
        if (!empty($filters['block_id'])) {
            $sql .= " AND l.block_id = ?";
            $params[] = $filters['block_id'];
        }
        // Free-text search matching lot number, type, section, block, occupant name, or reservation name
        if (!empty($filters['search'])) {
            $sql .= " AND (l.lot_number LIKE ? OR t.type_name LIKE ? OR s.section_name LIKE ? OR b.block_name LIKE ? OR occ.occupant_name LIKE ? OR rsv.reserved_for_name LIKE ?)";
            $term = '%' . $filters['search'] . '%';
            array_push($params, $term, $term, $term, $term, $term, $term);
        }
    }

    private function getEnrichedLotJoins() {
        return "
            JOIN blocks b ON l.block_id = b.block_id
            JOIN sections s ON b.section_id = s.section_id
            JOIN lot_types t ON l.lot_type_id = t.type_id
            LEFT JOIN (
                SELECT d.lot_id, 
                       TRIM(CONCAT(d.first_name, ' ', COALESCE(CONCAT(d.middle_name, ' '), ''), d.last_name, COALESCE(CONCAT(' ', d.suffix), ''))) AS occupant_name,
                       d.decedent_id,
                       d.dob,
                       d.dod,
                       d.contact_name,
                       d.contact_number,
                       d.is_cremated
                FROM decedent_records d
                INNER JOIN (
                    SELECT lot_id, MAX(decedent_id) AS max_did
                    FROM decedent_records
                    WHERE deleted_at IS NULL AND lot_id IS NOT NULL
                    GROUP BY lot_id
                ) md ON d.lot_id = md.lot_id AND d.decedent_id = md.max_did
            ) occ ON occ.lot_id = l.lot_id
            LEFT JOIN (
                SELECT er.lot_id,
                       er.expiration_id,
                       er.start_date AS lease_start_date,
                       er.end_date AS lease_end_date,
                       er.renewed AS lease_renewed,
                       er.exhumation_status,
                       er.notified_at AS lease_notified_at
                FROM expiration_records er
                INNER JOIN (
                    SELECT lot_id, MAX(expiration_id) AS max_eid
                    FROM expiration_records
                    GROUP BY lot_id
                ) me ON er.lot_id = me.lot_id AND er.expiration_id = me.max_eid
            ) exp ON exp.lot_id = l.lot_id
            LEFT JOIN (
                SELECT bs.lot_id,
                       bs.schedule_id,
                       bs.schedule_date,
                       bs.schedule_time,
                       bs.status AS schedule_status,
                       COALESCE(
                           TRIM(CONCAT(sd.first_name, ' ', sd.last_name)),
                           sr.full_name
                       ) AS reserved_for_name
                FROM burial_schedules bs
                INNER JOIN (
                    SELECT lot_id, MAX(schedule_id) AS max_sid
                    FROM burial_schedules
                    WHERE status IN ('Pending', 'Confirmed')
                    GROUP BY lot_id
                ) mbs ON bs.lot_id = mbs.lot_id AND bs.schedule_id = mbs.max_sid
                LEFT JOIN decedent_records sd ON bs.deceased_id = sd.decedent_id
                LEFT JOIN decedent_requests sr ON bs.decedent_request_id = sr.request_id
            ) rsv ON rsv.lot_id = l.lot_id
        ";
    }

    public function findAll($filters = [], $pagination = []) {
        $this->syncExpiredLots();
        $joins = $this->getEnrichedLotJoins();
        $sql = "
            SELECT l.*, b.block_name, s.section_name, t.type_name as lot_type_name,
                   occ.occupant_name, occ.decedent_id, occ.dob, occ.dod, occ.contact_name, occ.contact_number, occ.is_cremated,
                   exp.lease_start_date, exp.lease_end_date, exp.lease_renewed, exp.exhumation_status, exp.lease_notified_at,
                   rsv.schedule_id, rsv.schedule_date, rsv.schedule_time, rsv.schedule_status, rsv.reserved_for_name
            FROM lots l
            {$joins}
            WHERE 1=1
        ";
        $params = [];
        $this->applyFilters($sql, $params, $filters);

        $sql .= " ORDER BY s.section_name, b.block_name, l.lot_number";

        $page = null;
        $perPage = null;
        if (!empty($pagination['page']) || !empty($pagination['per_page'])) {
            $page = max(1, (int) ($pagination['page'] ?? 1));
            $perPage = max(1, min(100, (int) ($pagination['per_page'] ?? 10)));
        }

        if ($page !== null && $perPage !== null) {
            $offset = ($page - 1) * $perPage;
            $sql .= " LIMIT ?, ?";
            $params[] = $offset;
            $params[] = $perPage;
        }

        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    public function countAll($filters = []) {
        $this->syncExpiredLots();
        $joins = $this->getEnrichedLotJoins();
        $sql = "
            SELECT COUNT(*) AS total
            FROM lots l
            {$joins}
            WHERE 1=1
        ";
        $params = [];
        $this->applyFilters($sql, $params, $filters);

        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        $row = $stmt->fetch();
        return (int) ($row['total'] ?? 0);
    }

    public function findById($id) {
        $this->syncExpiredLots();
        $joins = $this->getEnrichedLotJoins();
        $stmt = $this->db->prepare("
            SELECT l.*, b.block_name, s.section_name, t.type_name as lot_type_name,
                   occ.occupant_name, occ.decedent_id, occ.dob, occ.dod, occ.contact_name, occ.contact_number, occ.is_cremated,
                   exp.lease_start_date, exp.lease_end_date, exp.lease_renewed, exp.exhumation_status, exp.lease_notified_at,
                   rsv.schedule_id, rsv.schedule_date, rsv.schedule_time, rsv.schedule_status, rsv.reserved_for_name
            FROM lots l
            {$joins}
            WHERE l.lot_id = ?
        ");
        $stmt->execute([$id]);
        return $stmt->fetch();
    }

    /**
     * Shared contract with python-ai microservice (BATCH AI-6 Pattern 2):
     * Queries the unified v_available_lots view ensuring PHP and Python services
     * always evaluate lot availability with 100% identical joins and conditions.
     *
     * @return array List of available lots with block, section, and type details
     */
    public function findAvailableLots() {
        $this->syncExpiredLots();
        $stmt = $this->db->query("SELECT * FROM v_available_lots");
        return $stmt->fetchAll();
    }

    // Decedent Records module audit, Batch J (CSV import) & Batch 2: lot_number
    // alone isn't unique cemetery-wide (only unique per block — see lots'
    // `block_id, lot_number` unique key), so a historical-records CSV
    // has to disambiguate by section and, optionally, block_name.
    // Case-insensitive on all parameters.
    public function findByNumberAndSection($lotNumber, $sectionName, $blockName = null) {
        $sql = "
            SELECT l.lot_id, l.lot_number, s.section_name, b.block_name
            FROM lots l
            JOIN blocks b ON l.block_id = b.block_id
            JOIN sections s ON b.section_id = s.section_id
            WHERE LOWER(l.lot_number) = LOWER(?) AND LOWER(s.section_name) = LOWER(?)
        ";
        $params = [trim((string) $lotNumber), trim((string) $sectionName)];
        if (!empty($blockName)) {
            $sql .= " AND LOWER(b.block_name) = LOWER(?)";
            $params[] = trim((string) $blockName);
        }
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    // Locking read for the transactional booking flow (Batch L2.3) — takes
    // an InnoDB record lock on this exact lot row for the life of the
    // caller's transaction, so a second concurrent booking attempt against
    // the same lot blocks here until the first transaction commits or
    // rolls back, instead of both readers independently seeing the same
    // pre-transition status. Only ever call this from inside an active
    // Database::transaction() — outside of one, PDO auto-commits right
    // after the SELECT and the lock is released immediately, providing no
    // protection. Deliberately does not run syncExpiredLots() (that stays
    // findById()'s lazy-sweep behavior, out of this batch's scope) and is
    // not a replacement for findById() elsewhere.
    public function findByIdForUpdate($id) {
        $stmt = $this->db->prepare("
            SELECT l.*, b.block_name, s.section_name, t.type_name as lot_type_name
            FROM lots l
            JOIN blocks b ON l.block_id = b.block_id
            JOIN sections s ON b.section_id = s.section_id
            JOIN lot_types t ON l.lot_type_id = t.type_id
            WHERE l.lot_id = ?
            FOR UPDATE
        ");
        $stmt->execute([$id]);
        return $stmt->fetch();
    }

    public function create($data) {
        $lotNumber = trim((string) ($data['lot_number'] ?? ''));
        if ($lotNumber === '') {
            $lotNumber = $this->generateLotNumber((int) $data['block_id']);
        }

        // lease_start_date/lease_end_date are intentionally not written here —
        // expiration_records is the sole source of truth for lease dates (see
        // ScheduleController, which creates one automatically on schedule
        // completion); these lots columns were never populated by any code
        // path and existed only as a dead, disconnected duplicate.
        $stmt = $this->db->prepare("
            INSERT INTO lots (block_id, lot_number, lot_type_id, status, price, dimensions, location_notes)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ");
        $success = $stmt->execute([
            $data['block_id'],
            $lotNumber,
            $data['lot_type_id'],
            $data['status'] ?? 'Available',
            $data['price'],
            $data['dimensions'] ?? null,
            $data['location_notes'] ?? null,
        ]);
        return $success ? (int) $this->db->lastInsertId() : false;
    }

    // Batch L2.2: status removed from this method's write capability
    // entirely (not just conditionally skipped) — this is metadata-only
    // now. lots.status has exactly one application-level write path left:
    // transitionStatus() below, always reached through
    // AutomationEngine::run() (see LotController::updateLot() for the
    // admin-override case, and ScheduleController/PaymentController/
    // RelocationController for automated transitions). A caller that still
    // passes a 'status' key in $data is silently ignored here by design —
    // Lot::update($id, ['status' => 'Occupied']) cannot write lots.status,
    // structurally, because the column is no longer in this SQL statement.
    public function update($id, $data) {
        $existing = $this->findById($id);
        if (!$existing) {
            return false;
        }

        $stmt = $this->db->prepare("
            UPDATE lots SET
                block_id = ?,
                lot_number = ?,
                lot_type_id = ?,
                price = ?,
                dimensions = ?,
                location_notes = ?
            WHERE lot_id = ?
        ");
        return $stmt->execute([
            $data['block_id'] ?? $existing['block_id'],
            $data['lot_number'] ?? $existing['lot_number'],
            $data['lot_type_id'] ?? $existing['lot_type_id'],
            $data['price'] ?? $existing['price'],
            array_key_exists('dimensions', $data) ? $data['dimensions'] : $existing['dimensions'],
            array_key_exists('location_notes', $data) ? $data['location_notes'] : $existing['location_notes'],
            $id,
        ]);
    }

    // Batch B (reservation module audit): every lot-status transition's
    // legal "from" statuses used to be a literal array re-typed at each call
    // site across ScheduleController, RelocationController, PaymentController
    // and Lot itself — the same ['Available', 'Reserved'] copied five times
    // in ScheduleController alone. Centralizing them here means two call
    // sites can no longer silently disagree about what states a given
    // transition is legal from. Keyed by "event::newStatus" rather than just
    // "event" because relocation.completed legitimately drives two different
    // target statuses for two different lots (the released from_lot and the
    // occupied to_lot) in the same call. The two transitions that really are
    // intentionally unrestricted (an admin's direct override, and the
    // from_lot release half of relocation.completed) are declared as such
    // explicitly via FROM_STATUSES_UNRESTRICTED, so that deliberate choice
    // stays distinguishable from a rule nobody got around to adding yet.
    private const FROM_STATUSES_UNRESTRICTED = '__unrestricted__';

    private const LOT_TRANSITION_RULES = [
        'schedule.confirmed::Reserved' => ['Available', 'Reserved'],
        'schedule.completed::Occupied' => ['Available', 'Reserved'],
        'schedule.cancelled::Available' => ['Available', 'Reserved'],
        'schedule.auto_cancelled_unpaid::Available' => ['Available', 'Reserved'],
        'lot.expired::Expired' => ['Occupied'],
        'relocation.approved::Reserved' => ['Available'],
        'relocation.denied::Available' => ['Reserved', 'Available'],
        'relocation.cancelled::Available' => ['Reserved', 'Available'],
        'relocation.completed::Available' => self::FROM_STATUSES_UNRESTRICTED,
        'relocation.completed::Occupied' => ['Reserved'],
        'payment.verified::Reserved' => ['Available'],
        'booking.allocation_changed::Available' => ['Available', 'Reserved'],
        'booking.allocation_changed::Reserved' => ['Available'],
        'decedent.registered::Occupied' => ['Available', 'Reserved', 'Occupied'],
    ];

    // lot.admin_override's newStatus is whatever the admin picked, so it
    // can't be a fixed part of the table key above — Classification E from
    // the L1/L2 audits established this as the one intentionally
    // unrestricted admin override, not a lifecycle rule, and that stays true
    // for any target status.
    public static function allowedFromStatusesFor($event, $newStatus) {
        if ($event === 'lot.admin_override') {
            return null;
        }
        $key = $event . '::' . $newStatus;
        if (!array_key_exists($key, self::LOT_TRANSITION_RULES)) {
            throw new RuntimeException("No lot transition rule declared for '{$key}' — add one to Lot::LOT_TRANSITION_RULES rather than passing an ad hoc allowed-from-statuses array at the call site.");
        }
        $rule = self::LOT_TRANSITION_RULES[$key];
        return $rule === self::FROM_STATUSES_UNRESTRICTED ? null : $rule;
    }

    // The sole application-level write path for lots.status (Batch L2.2 —
    // update() above no longer touches this column at all, structurally,
    // not just by convention). Used both for automated transitions (a
    // booking getting confirmed/completed/cancelled, a payment verifying, a
    // relocation being approved/completed) and for an admin's direct status
    // override via LotController::updateLot(). $allowedFromStatuses, when
    // given, rejects (returns false, writes nothing) if the lot isn't
    // currently in one of those statuses — callers wrap this in
    // AutomationEngine::run() so a rejection raises a reviewable
    // system_exceptions entry instead of silently doing nothing or
    // overwriting a status some other process already moved past. Callers
    // should obtain this value from allowedFromStatusesFor() above rather
    // than a literal array, so every transition's rule lives in one place.
    public function transitionStatus($lotId, $newStatus, $allowedFromStatuses = null) {
        $existing = $this->findById($lotId);
        if (!$existing) {
            return false;
        }
        if ($allowedFromStatuses !== null && !in_array($existing['status'], $allowedFromStatuses, true)) {
            return false;
        }

        $stmt = $this->db->prepare("UPDATE lots SET status = ? WHERE lot_id = ?");
        return $stmt->execute([$newStatus, (int) $lotId]);
    }

    public function delete($id) {
        $stmt = $this->db->prepare("DELETE FROM lots WHERE lot_id = ?");
        return $stmt->execute([$id]);
    }

    public function generateLotNumber($blockId) {
        $stmt = $this->db->prepare("SELECT COUNT(*) AS count FROM lots WHERE block_id = ?");
        $stmt->execute([$blockId]);
        $count = (int) $stmt->fetchColumn();
        return 'L' . ($count + 1);
    }

    public function createCategory($data) {
        $stmt = $this->db->prepare("INSERT INTO lot_types (type_name, description) VALUES (?, ?)");
        return $stmt->execute([$data['type_name'], $data['description'] ?? null]);
    }

    public function updateCategory($id, $data) {
        $stmt = $this->db->prepare("UPDATE lot_types SET type_name = ?, description = ? WHERE type_id = ?");
        return $stmt->execute([$data['type_name'], $data['description'] ?? null, $id]);
    }

    public function deleteCategory($id) {
        $stmt = $this->db->prepare("DELETE FROM lot_types WHERE type_id = ?");
        return $stmt->execute([$id]);
    }

    /**
     * Batch creates sequential lots in a block with automatic number assignment,
     * uniqueness checks, and block/section count synchronization inside a transaction.
     */
    public function batchCreateLots($blockId, $lotTypeId, $count, $prefix = 'L', $startNum = null, $price = 0, $dimensions = null, $notes = null) {
        $count = max(1, min(100, (int) $count));
        $blockId = (int) $blockId;
        $lotTypeId = (int) $lotTypeId;
        $price = (float) $price;
        $prefix = trim((string) $prefix);
        if ($prefix === '') {
            $prefix = 'L';
        }

        // Validate block exists
        $blockStmt = $this->db->prepare("SELECT block_id, section_id FROM blocks WHERE block_id = ?");
        $blockStmt->execute([$blockId]);
        $block = $blockStmt->fetch();
        if (!$block) {
            return ['success' => false, 'error' => 'Invalid block specified'];
        }

        // Validate lot_type exists
        $typeStmt = $this->db->prepare("SELECT type_id FROM lot_types WHERE type_id = ?");
        $typeStmt->execute([$lotTypeId]);
        if (!$typeStmt->fetch()) {
            return ['success' => false, 'error' => 'Invalid lot type specified'];
        }

        // Determine starting number if not provided
        if ($startNum === null || (int) $startNum <= 0) {
            $countStmt = $this->db->prepare("SELECT COUNT(*) FROM lots WHERE block_id = ?");
            $countStmt->execute([$blockId]);
            $startNum = (int) $countStmt->fetchColumn() + 1;
        } else {
            $startNum = (int) $startNum;
        }

        $createdLotNumbers = [];
        $createdIds = [];

        Database::transaction(function() use ($blockId, $lotTypeId, $count, $prefix, $startNum, $price, $dimensions, $notes, $block, &$createdLotNumbers, &$createdIds) {
            $insertStmt = $this->db->prepare("
                INSERT INTO lots (block_id, lot_number, lot_type_id, status, price, dimensions, location_notes)
                VALUES (?, ?, ?, 'Available', ?, ?, ?)
            ");

            $currNum = $startNum;
            for ($i = 0; $i < $count; $i++) {
                $lotNumber = $prefix . $currNum;

                // Ensure unique within block
                $checkStmt = $this->db->prepare("SELECT lot_id FROM lots WHERE block_id = ? AND lot_number = ?");
                $checkStmt->execute([$blockId, $lotNumber]);
                if ($checkStmt->fetch()) {
                    // Try next number
                    $currNum++;
                    $i--;
                    continue;
                }

                $insertStmt->execute([
                    $blockId,
                    $lotNumber,
                    $lotTypeId,
                    $price,
                    $dimensions ?: null,
                    $notes ?: null
                ]);
                $createdIds[] = (int) $this->db->lastInsertId();
                $createdLotNumbers[] = $lotNumber;
                $currNum++;
            }

            // Update block count
            $updBlock = $this->db->prepare("
                UPDATE blocks SET total_lots = (SELECT COUNT(*) FROM lots WHERE block_id = ?)
                WHERE block_id = ?
            ");
            $updBlock->execute([$blockId, $blockId]);

            // Update section count
            $updSec = $this->db->prepare("
                UPDATE sections s
                SET total_blocks = (SELECT COUNT(*) FROM blocks WHERE section_id = s.section_id),
                    total_lots = (SELECT COUNT(l.lot_id) FROM blocks b JOIN lots l ON b.block_id = l.block_id WHERE b.section_id = s.section_id)
                WHERE s.section_id = ?
            ");
            $updSec->execute([$block['section_id']]);
        });

        return [
            'success' => true,
            'count' => count($createdIds),
            'lot_numbers' => $createdLotNumbers,
            'lot_ids' => $createdIds
        ];
    }

    /**
     * Proactively executes expiration sweeps, recalibrates block and section counts,
     * and returns the updated cemetery-wide lot stats.
     */
    public function syncAllLotMetrics() {
        // 1. Run expired lots sweep
        $this->syncExpiredLots();

        // 2. Refresh total_lots for all blocks
        $this->db->exec("
            UPDATE blocks b
            SET total_lots = (
                SELECT COUNT(*) FROM lots l WHERE l.block_id = b.block_id
            )
        ");

        // 3. Refresh total_blocks & total_lots for all sections
        $this->db->exec("
            UPDATE sections s
            SET total_blocks = (
                SELECT COUNT(*) FROM blocks b WHERE b.section_id = s.section_id
            ),
            total_lots = (
                SELECT COUNT(l.lot_id)
                FROM blocks b
                JOIN lots l ON b.block_id = l.block_id
                WHERE b.section_id = s.section_id
            )
        ");

        // 4. Return current fresh stats
        return $this->getStats();
    }

    public function findCategories() {
        return $this->getLotTypes();
    }

    public function getStats() {
        $this->syncExpiredLots();
        $stmt = $this->db->query("
            SELECT
                COUNT(*) as total,
                SUM(CASE WHEN status = 'Available' THEN 1 ELSE 0 END) as available,
                SUM(CASE WHEN status = 'Occupied' THEN 1 ELSE 0 END) as occupied,
                SUM(CASE WHEN status = 'Reserved' THEN 1 ELSE 0 END) as reserved,
                SUM(CASE WHEN status = 'Expired' THEN 1 ELSE 0 END) as expired
            FROM lots
        ");
        return $stmt->fetch();
    }

    public function getLotTypes() {
        $stmt = $this->db->query("SELECT * FROM lot_types ORDER BY type_name");
        return $stmt->fetchAll();
    }
}
