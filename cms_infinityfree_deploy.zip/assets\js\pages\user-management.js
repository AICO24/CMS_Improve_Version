document.addEventListener('DOMContentLoaded', async function() {
    const currentUser = await requireRole(['admin']);
    if (!currentUser) return;

    document.getElementById('logoutBtn').addEventListener('click', () => {
        api.logout();
    });

    const toggleBtn = document.getElementById('toggleSidebar');
    const sidebar = document.querySelector('.sidebar');
    if (toggleBtn && sidebar) {
        toggleBtn.addEventListener('change', () => {
            sidebar.classList.toggle('collapsed');
        });
    }

    const usersTableBody = document.getElementById('usersTableBody');
    const totalUsers = document.getElementById('totalUsers');
    const totalUsersMeta = document.getElementById('totalUsersMeta');
    const adminCount = document.getElementById('adminCount');
    const adminCountMeta = document.getElementById('adminCountMeta');
    const staffCount = document.getElementById('staffCount');
    const staffCountMeta = document.getElementById('staffCountMeta');
    const inactiveCount = document.getElementById('inactiveCount');
    const inactiveCountMeta = document.getElementById('inactiveCountMeta');
    const searchQuery = document.getElementById('searchQuery');
    const searchUsersBtn = document.getElementById('searchUsersBtn');
    const filterRole = document.getElementById('filterRole');
    const filterActive = document.getElementById('filterActive');
    const clearFilters = document.getElementById('clearFilters');
    const openAddUser = document.getElementById('openAddUser');
    const bulkActivateBtn = document.getElementById('bulkActivateBtn');
    const bulkDeactivateBtn = document.getElementById('bulkDeactivateBtn');
    const bulkDeleteBtn = document.getElementById('bulkDeleteBtn');
    const bulkSelectedCount = document.getElementById('bulkSelectedCount');
    const selectAllUsers = document.getElementById('selectAllUsers');
    const refreshActivityBtn = document.getElementById('refreshActivityBtn');
    const userActivityList = document.getElementById('userActivityList');
    const miniAdminCount = document.getElementById('miniAdminCount');
    const miniStaffCount = document.getElementById('miniStaffCount');
    const miniInactiveCount = document.getElementById('miniInactiveCount');
    const userModal = document.getElementById('userModal');
    const modalTitle = document.getElementById('modalTitle');
    const modalSubtitle = document.getElementById('modalSubtitle');
    const userForm = document.getElementById('userForm');
    const closeModal = document.querySelector('#userModal .close, #userModal .close-view, #closeUserModal');
    const cancelUserForm = document.getElementById('cancelUserForm');

    const perPage = 8;
    const paginationInfo = document.getElementById('paginationInfo');
    const pageJumpForm = document.getElementById('paginationJumpForm');
    const pageJumpInput = document.getElementById('pageJumpInput');
    const pageJumpBtn = document.getElementById('pageJumpBtn');
    const prevPageBtn = document.getElementById('prevPage');
    const nextPageBtn = document.getElementById('nextPage');

    const requiredNodes = {
        usersTableBody,
        totalUsers,
        adminCount,
        staffCount,
        inactiveCount,
        searchQuery,
        filterRole,
        filterActive,
        openAddUser,
        bulkActivateBtn,
        bulkDeactivateBtn,
        bulkDeleteBtn,
        selectAllUsers,
        refreshActivityBtn,
        userActivityList,
        userModal,
        modalTitle,
        modalSubtitle,
        userForm,
        paginationInfo,
        pageJumpForm,
        pageJumpInput,
        pageJumpBtn,
        prevPageBtn,
        nextPageBtn,
    };

    if (Object.values(requiredNodes).some((node) => !node)) {
        console.error('User management page is missing required DOM nodes.');
        return;
    }

    const userFields = {
        userId: document.getElementById('userId'),
        username: document.getElementById('username'),
        fullName: document.getElementById('fullName'),
        email: document.getElementById('email'),
        contactNumber: document.getElementById('contactNumber'),
        address: document.getElementById('address'),
        role: document.getElementById('role'),
        password: document.getElementById('password'),
        isActive: document.getElementById('isActive'),
    };

    let selectedUserIds = new Set();
    const pagination = createPagination({
        prevBtn: prevPageBtn,
        nextBtn: nextPageBtn,
        infoEl: paginationInfo,
        jumpForm: pageJumpForm,
        jumpInput: pageJumpInput,
        jumpBtn: pageJumpBtn,
        itemLabel: 'user',
        onChange: loadUsers,
    });

    function buildFilters() {
        const filters = {};
        if (filterRole.value) filters.role = filterRole.value;
        if (filterActive.value !== '') filters.is_active = filterActive.value;
        if (searchQuery.value.trim()) filters.q = searchQuery.value.trim();
        return filters;
    }

    async function loadUsers() {
        try {
            const filters = buildFilters();
            const params = new URLSearchParams(filters);
            params.set('page', pagination.page);
            params.set('per_page', perPage);
            const result = await api.request(`users?${params.toString()}`, { method: 'GET' });
            const users = Array.isArray(result.data) ? result.data : [];
            renderUsers(users);
            pagination.render(result.meta || { page: 1, total_pages: 1, total: users.length });
            await updateStats(filters, result.meta);
        } catch (error) {
            usersTableBody.innerHTML = '<tr><td colspan="7">Failed to load users. Please refresh.</td></tr>';
            pagination.render({ page: 1, total_pages: 1, total: 0 });
            console.error('Failed to load users:', error);
        }
    }

    // Breakdown cards reflect the current search+filter context (matching the
    // pre-pagination behavior of counting within the filtered result set), but
    // can no longer be derived from the current page's rows alone — each count
    // is a lightweight per_page=1 request whose meta.total is the real count.
    async function updateStats(filters, meta) {
        const total = meta && typeof meta.total === 'number' ? meta.total : 0;
        totalUsers.innerText = total;
        if (totalUsersMeta) {
            totalUsersMeta.textContent = 'Total accounts';
        }
        const badgeAllUsers = document.getElementById('badgeAllUsers');
        if (badgeAllUsers) {
            badgeAllUsers.textContent = total;
        }

        try {
            const countFor = (overrides) => {
                const params = new URLSearchParams({ ...filters, ...overrides, per_page: 1 });
                return api.request(`users?${params.toString()}`, { method: 'GET' });
            };
            const [adminResult, staffResult, inactiveResult] = await Promise.all([
                countFor({ role: 'admin' }),
                countFor({ role: 'staff' }),
                countFor({ is_active: 0 }),
            ]);
            const adminTotal = adminResult.meta && typeof adminResult.meta.total === 'number' ? adminResult.meta.total : 0;
            const staffTotal = staffResult.meta && typeof adminResult.meta.total === 'number' ? staffResult.meta.total : 0;
            const inactiveTotal = inactiveResult.meta && typeof inactiveResult.meta.total === 'number' ? inactiveResult.meta.total : 0;

            adminCount.innerText = adminTotal;
            staffCount.innerText = staffTotal;
            inactiveCount.innerText = inactiveTotal;

            if (adminCountMeta) {
                adminCountMeta.textContent = 'Admin accounts';
            }
            if (staffCountMeta) {
                staffCountMeta.textContent = 'Staff accounts';
            }
            if (inactiveCountMeta) {
                inactiveCountMeta.textContent = 'Inactive accounts';
            }
            if (miniAdminCount) miniAdminCount.innerText = adminTotal;
            if (miniStaffCount) miniStaffCount.innerText = staffTotal;
            if (miniInactiveCount) miniInactiveCount.innerText = inactiveTotal;
        } catch (error) {
            console.error('Failed to load user breakdown stats:', error);
        }
    }

    async function loadRecentActivity() {
        if (!userActivityList) return;
        userActivityList.innerHTML = '<li class="activity-item is-loading">Loading recent activity...</li>';

        try {
            const logs = await api.request('audit-logs?limit=5&offset=0', { method: 'GET' });
            if (!Array.isArray(logs) || logs.length === 0) {
                userActivityList.innerHTML = '<li class="activity-item is-loading">No activity recorded yet.</li>';
                return;
            }

            const actionMap = {
                'User created': { label: 'Created', tone: 'is-success', verb: 'created a new account for' },
                'User updated': { label: 'Updated', tone: 'is-info', verb: 'updated account details for' },
                'User deleted': { label: 'Deleted', tone: 'is-danger', verb: 'deleted account' },
                'Users deleted': { label: 'Deleted', tone: 'is-danger', verb: 'deleted multiple accounts' },
                'Users activated': { label: 'Activated', tone: 'is-success', verb: 'activated account(s)' },
                'Users deactivated': { label: 'Deactivated', tone: 'is-warning', verb: 'deactivated account(s)' },
                'Login successful': { label: 'Signed in', tone: 'is-info', verb: 'signed in successfully' },
                'Password reset': { label: 'Reset', tone: 'is-warning', verb: 'reset password for' },
                'Profile updated': { label: 'Updated', tone: 'is-info', verb: 'updated profile for' },
            };

            userActivityList.innerHTML = logs.map((log) => {
                const rawAction = log.action || 'Activity';
                const actorName = log.user_full_name || log.username || 'System';
                const mapped = actionMap[rawAction] || { label: rawAction, tone: /delete|remove|deactivate|reject|failed/i.test(rawAction) ? 'is-danger' : 'is-success', verb: 'performed an action on' };

                let targetText = 'system record';
                let description = mapped.verb;

                if (log.details) {
                    const raw = String(log.details).trim();
                    try {
                        const parsed = raw.startsWith('{') || raw.startsWith('[') ? JSON.parse(raw) : null;
                        const detailsObj = parsed && typeof parsed === 'object' ? parsed : null;

                        if (detailsObj) {
                            const candidate = detailsObj.target_user
                                || detailsObj.deleted_username
                                || detailsObj.created_username
                                || detailsObj.username
                                || detailsObj.user
                                || detailsObj.full_name
                                || detailsObj.name
                                || detailsObj.email;

                            if (candidate) {
                                targetText = String(candidate);
                            }

                            const values = Object.values(detailsObj)
                                .filter((value) => typeof value === 'string' || typeof value === 'number')
                                .map(String)
                                .filter((value) => value.trim());

                            if (values.length) {
                                description = `${mapped.verb} ${values.slice(0, 2).join(' • ')}`;
                            }
                        } else if (raw) {
                            const clean = raw.replace(/\s+/g, ' ').slice(0, 80);
                            targetText = clean;
                            description = `${mapped.verb} ${clean}`;
                        }
                    } catch (error) {
                        const clean = raw.replace(/\s+/g, ' ').slice(0, 80);
                        targetText = clean;
                        description = `${mapped.verb} ${clean}`;
                    }
                }

                const time = log.created_at ? new Date(log.created_at).toLocaleString([], {
                    month: 'short',
                    day: 'numeric',
                    hour: 'numeric',
                    minute: '2-digit'
                }) : 'Recently';

                return `
                    <li class="activity-item">
                        <div class="activity-marker ${mapped.tone}"></div>
                        <div class="activity-meta">
                            <div class="activity-headline">
                                <strong>${actorName}</strong>
                                <span class="activity-dot">•</span>
                                <span class="activity-action-text">${mapped.label}</span>
                            </div>
                            <span>${description}</span>
                            <small>${targetText}</small>
                        </div>
                        <div class="activity-side">
                            <span class="activity-time">${time}</span>
                            <span class="activity-tag ${mapped.tone}">${mapped.label}</span>
                        </div>
                    </li>
                `;
            }).join('');
        } catch (error) {
            userActivityList.innerHTML = '<li class="activity-item is-loading">Unable to load recent activity.</li>';
            console.error('Failed to load recent activity:', error);
        }
    }

    function syncBulkControls() {
        const count = selectedUserIds.size;
        const bulkToolbar = document.getElementById('bulkToolbar');
        if (bulkToolbar) {
            bulkToolbar.style.display = count > 0 ? 'flex' : 'none';
        }
        bulkSelectedCount.textContent = count ? `${count} user${count > 1 ? 's' : ''} selected` : 'No users selected';
        bulkActivateBtn.disabled = count === 0;
        bulkDeactivateBtn.disabled = count === 0;
        bulkDeleteBtn.disabled = count === 0;

        const rowCheckboxes = usersTableBody.querySelectorAll('.user-select');
        if (rowCheckboxes.length) {
            const allChecked = [...rowCheckboxes].every((checkbox) => checkbox.checked);
            selectAllUsers.checked = allChecked;
        } else {
            selectAllUsers.checked = false;
        }
    }

    function escapeHtml(str) {
        if (str === null || str === undefined) return '';
        return String(str)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#39;');
    }

    function formatLoginCell(dateVal) {
        if (!dateVal || dateVal === 'Never') {
            return '<span class="text-muted" style="color:#94a3b8; font-size:0.80rem;">Never</span>';
        }
        try {
            const d = new Date(dateVal);
            if (isNaN(d.getTime())) return `<span class="cell-date">${escapeHtml(dateVal)}</span>`;
            const dateStr = d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
            const timeStr = d.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' });
            return `
                <div class="table-datetime-cell">
                    <span class="cell-date">${dateStr}</span>
                    <span class="cell-time"><i class="far fa-clock"></i> ${timeStr}</span>
                </div>
            `;
        } catch (_) {
            return `<span class="cell-date">${escapeHtml(dateVal)}</span>`;
        }
    }

    function renderUsers(users) {
        if (!Array.isArray(users) || users.length === 0) {
            usersTableBody.innerHTML = '<tr><td colspan="9" style="text-align:center; padding: 32px 16px; color: #64748b; font-size: 0.88rem;">No users found matching the filter criteria.</td></tr>';
            syncBulkControls();
            return;
        }

        usersTableBody.innerHTML = users.map(user => {
            const roleStr = String(user.role_title || user.role || 'Staff').toLowerCase();
            let roleClass = 'role-staff';
            let roleLabel = 'Staff';
            if (roleStr.includes('admin')) {
                roleClass = 'role-admin';
                roleLabel = 'Administrator';
            } else if (roleStr.includes('user') || roleStr.includes('citizen') || roleStr.includes('client')) {
                roleClass = 'role-user';
                roleLabel = 'User';
            }

            const statusClass = user.is_active ? 'status-active' : 'status-inactive';
            const statusLabel = user.is_active ? 'Active' : 'Inactive';

            const usernamePill = `<span class="username-pill">${escapeHtml(user.username || '—')}</span>`;
            const fullNameCell = `<span class="user-fullname" title="${escapeHtml(user.full_name || '')}">${escapeHtml(user.full_name || '—')}</span>`;
            const emailCell = `<span class="user-email" title="${escapeHtml(user.email || '')}">${escapeHtml(user.email || '—')}</span>`;

            const createdDate = user.created_at ? new Date(user.created_at).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }) : '—';
            const lastLoginDate = formatLoginCell(user.last_login);

            return `
                <tr data-id="${user.user_id}">
                    <td class="table-select-col"><input type="checkbox" class="user-select" data-id="${user.user_id}" ${selectedUserIds.has(Number(user.user_id)) ? 'checked' : ''} aria-label="Select user ${escapeHtml(user.username)}"></td>
                    <td class="col-username">${usernamePill}</td>
                    <td class="col-fullname">${fullNameCell}</td>
                    <td class="col-email">${emailCell}</td>
                    <td class="col-role"><span class="status-badge ${roleClass}">${roleLabel}</span></td>
                    <td class="col-status"><span class="status-badge ${statusClass}">${statusLabel}</span></td>
                    <td class="col-created">${createdDate}</td>
                    <td class="col-last-login">${lastLoginDate}</td>
                    <td class="col-actions">
                        <div class="action-buttons">
                            <button class="btn-row-action btn-row-action--edit btn-view" title="Edit User Details" aria-label="Edit User"><i class="fas fa-pen-to-square"></i></button>
                            <button class="btn-row-action btn-row-action--delete btn-delete-row" title="Delete User Account" aria-label="Delete User"><i class="fas fa-trash-can"></i></button>
                        </div>
                    </td>
                </tr>
            `;
        }).join('');

        usersTableBody.querySelectorAll('.user-select').forEach((checkbox) => {
            checkbox.addEventListener('change', () => {
                const id = Number(checkbox.dataset.id);
                if (checkbox.checked) {
                    selectedUserIds.add(id);
                } else {
                    selectedUserIds.delete(id);
                }
                syncBulkControls();
            });
        });

        usersTableBody.querySelectorAll('.btn-view').forEach(btn => {
            btn.addEventListener('click', () => {
                const id = btn.closest('tr').dataset.id;
                openEditUser(id);
            });
        });

        usersTableBody.querySelectorAll('.btn-delete-row').forEach(btn => {
            btn.addEventListener('click', async () => {
                const id = btn.closest('tr').dataset.id;
                if (!confirm('Delete this user? This cannot be undone.')) return;
                try {
                    await api.request(`users/${id}`, { method: 'DELETE' });
                    await loadUsers();
                } catch (error) {
                    alert(error.message || 'Failed to delete user');
                }
            });
        });
    }

    function resetModal() {
        modalTitle.innerText = 'Add User';
        if (modalSubtitle) modalSubtitle.textContent = 'Create a new account and assign access.';
        userFields.userId.value = '';
        userFields.username.value = '';
        userFields.fullName.value = '';
        userFields.email.value = '';
        userFields.contactNumber.value = '';
        userFields.address.value = '';
        userFields.role.value = 'staff';
        userFields.password.value = '';
        userFields.isActive.value = '1';
    }

    const userModalContent = document.querySelector('#userModal .user-modal-content');
    const modalScrollButtons = document.querySelectorAll('#userModal .modal-scroll-btn');

    function updateModalScrollButtons() {
        if (!userModalContent) return;
        const maxScroll = userModalContent.scrollHeight - userModalContent.clientHeight;
        const atTop = userModalContent.scrollTop <= 6;
        const atBottom = userModalContent.scrollTop >= maxScroll - 6;

        modalScrollButtons.forEach((button) => {
            const direction = button.dataset.scrollDir;
            const shouldDisable = direction === 'up' ? atTop : atBottom;
            button.disabled = shouldDisable;
        });
    }

    modalScrollButtons.forEach((button) => {
        button.addEventListener('click', () => {
            if (!userModalContent) return;
            const direction = button.dataset.scrollDir === 'up' ? -1 : 1;
            userModalContent.scrollBy({ top: direction * 180, behavior: 'smooth' });
        });
    });

    if (userModalContent) {
        userModalContent.addEventListener('scroll', updateModalScrollButtons);
    }

    function showModal() {
        userModal.style.display = 'flex';
        requestAnimationFrame(updateModalScrollButtons);
    }

    function hideModal() {
        userModal.style.display = 'none';
    }

    async function openEditUser(userId) {
        try {
            const user = await api.request(`users/${userId}`, { method: 'GET' });
            modalTitle.innerText = 'Edit User';
            if (modalSubtitle) modalSubtitle.textContent = 'Update account details and permissions.';
            userFields.userId.value = user.user_id;
            userFields.username.value = user.username;
            userFields.fullName.value = user.full_name;
            userFields.email.value = user.email;
            userFields.contactNumber.value = user.contact_number || '';
            userFields.address.value = user.address || '';
            const currentRole = (user.role_title || user.role || 'staff').toLowerCase();
            userFields.role.value = currentRole.includes('admin') ? 'admin' : (currentRole.includes('user') ? 'user' : 'staff');
            userFields.password.value = '';
            userFields.isActive.value = user.is_active ? '1' : '0';
            showModal();
        } catch (error) {
            alert(error.message || 'Failed to load user details');
        }
    }

    function debounce(fn, wait) {
        let timeout;
        return function(...args) {
            clearTimeout(timeout);
            timeout = setTimeout(() => fn.apply(this, args), wait);
        };
    }

    userForm.addEventListener('submit', async function(e) {
        e.preventDefault();
        const roleVal = userFields.role.value;
        const roleId = roleVal === 'admin' ? 1 : (roleVal === 'user' ? 3 : 2);
        const payload = {
            username: userFields.username.value.trim(),
            full_name: userFields.fullName.value.trim(),
            email: userFields.email.value.trim(),
            contact_number: userFields.contactNumber.value.trim(),
            address: userFields.address.value.trim(),
            role_id: roleId,
            is_active: parseInt(userFields.isActive.value, 10),
        };

        if (userFields.password.value.trim()) {
            payload.password = userFields.password.value;
        }

        const userId = userFields.userId.value;
        if (!userId && !payload.password) {
            alert('Password is required when creating a new user.');
            return;
        }

        const saveBtn = userForm.querySelector('button[type="submit"]');
        await withButtonLoading(saveBtn, async () => {
            try {
                const result = userId
                    ? await api.request(`users/${userId}`, { method: 'PUT', body: payload })
                    : await api.request('users', { method: 'POST', body: payload });

                if (result.success) {
                    hideModal();
                    pagination.reset();
                    await loadUsers();
                } else {
                    alert(result.error || 'Unable to save user');
                }
            } catch (error) {
                alert(error.message || 'Failed to save user');
            }
        });
    });

    async function runBulkAction(action) {
        if (!selectedUserIds.size) return;

        const labels = {
            activate: 'activate',
            deactivate: 'deactivate',
            delete: 'delete',
        };

        const confirmed = action === 'delete'
            ? confirm(`Delete ${selectedUserIds.size} selected user${selectedUserIds.size > 1 ? 's' : ''}?`) 
            : true;

        if (!confirmed) return;

        try {
            const result = await api.request('users/bulk', {
                method: 'POST',
                body: {
                    action: labels[action],
                    user_ids: [...selectedUserIds],
                },
            });

            if (result.success) {
                selectedUserIds.clear();
                syncBulkControls();
                await loadUsers();
            } else {
                alert(result.error || 'Bulk action failed');
            }
        } catch (error) {
            alert(error.message || 'Bulk action failed');
        }
    }

    bulkActivateBtn.addEventListener('click', () => runBulkAction('activate'));
    bulkDeactivateBtn.addEventListener('click', () => runBulkAction('deactivate'));
    bulkDeleteBtn.addEventListener('click', () => runBulkAction('delete'));
    selectAllUsers.addEventListener('change', () => {
        const checkboxes = usersTableBody.querySelectorAll('.user-select');
        checkboxes.forEach((checkbox) => {
            const id = Number(checkbox.dataset.id);
            const shouldCheck = selectAllUsers.checked;
            checkbox.checked = shouldCheck;
            if (shouldCheck) selectedUserIds.add(id);
            else selectedUserIds.delete(id);
        });
        syncBulkControls();
    });

    // ==========================================
    // View Tabs Switching (Directory vs Activity)
    // ==========================================
    const tabUsersDirectory = document.getElementById('tabUsersDirectory');
    const tabSecurityActivity = document.getElementById('tabSecurityActivity');
    const paneUsersDirectory = document.getElementById('paneUsersDirectory');
    const paneSecurityActivity = document.getElementById('paneSecurityActivity');

    const sectionLabelRegistry = document.getElementById('sectionLabelRegistry');

    function switchViewTab(targetTab) {
        if (targetTab === 'activity') {
            tabSecurityActivity.classList.add('active');
            tabSecurityActivity.setAttribute('aria-selected', 'true');
            tabUsersDirectory.classList.remove('active');
            tabUsersDirectory.setAttribute('aria-selected', 'false');

            paneSecurityActivity.style.display = 'flex';
            paneSecurityActivity.classList.add('active');
            paneUsersDirectory.style.display = 'none';
            paneUsersDirectory.classList.remove('active');

            if (sectionLabelRegistry) {
                sectionLabelRegistry.innerHTML = '<i class="fas fa-shield-halved"></i> Security &amp; Activity Log';
            }

            loadRecentActivity();
        } else {
            tabUsersDirectory.classList.add('active');
            tabUsersDirectory.setAttribute('aria-selected', 'true');
            tabSecurityActivity.classList.remove('active');
            tabSecurityActivity.setAttribute('aria-selected', 'false');

            paneUsersDirectory.style.display = 'flex';
            paneUsersDirectory.classList.add('active');
            paneSecurityActivity.style.display = 'none';
            paneSecurityActivity.classList.remove('active');

            if (sectionLabelRegistry) {
                sectionLabelRegistry.innerHTML = '<i class="fas fa-calendar-check"></i> User Registry';
            }
        }
    }

    if (tabUsersDirectory) {
        tabUsersDirectory.addEventListener('click', () => switchViewTab('directory'));
    }
    if (tabSecurityActivity) {
        tabSecurityActivity.addEventListener('click', () => switchViewTab('activity'));
    }

    // ==========================================
    // Interactive Filterable KPI Stat Cards
    // ==========================================
    const filterableCards = document.querySelectorAll('.stat-card-filterable');

    function setActiveFilterCard(filterType) {
        filterableCards.forEach(card => {
            const isMatch = card.dataset.filter === filterType;
            card.classList.toggle('is-active-filter', isMatch);
            card.classList.toggle('active', isMatch);
            card.setAttribute('aria-pressed', isMatch ? 'true' : 'false');
        });
    }

    filterableCards.forEach(card => {
        card.addEventListener('click', () => {
            const filterType = card.dataset.filter;
            setActiveFilterCard(filterType);

            if (filterType === 'all') {
                filterRole.value = '';
                filterActive.value = '';
            } else if (filterType === 'admin') {
                filterRole.value = 'admin';
                filterActive.value = '';
            } else if (filterType === 'staff') {
                filterRole.value = 'staff';
                filterActive.value = '';
            } else if (filterType === 'inactive') {
                filterRole.value = '';
                filterActive.value = '0';
            }

            // Ensure Directory tab is active when clicking a metric
            switchViewTab('directory');
            pagination.reset();
            selectedUserIds.clear();
            loadUsers();
        });

        card.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                card.click();
            }
        });
    });

    function syncCardFromDropdowns() {
        const role = filterRole.value;
        const active = filterActive.value;

        if (active === '0') {
            setActiveFilterCard('inactive');
        } else if (role === 'admin') {
            setActiveFilterCard('admin');
        } else if (role === 'staff') {
            setActiveFilterCard('staff');
        } else if (!role && !active) {
            setActiveFilterCard('all');
        } else {
            setActiveFilterCard('');
        }
    }

    const refreshFiltered = debounce(() => {
        pagination.reset();
        selectedUserIds.clear();
        loadUsers();
    }, 300);

    searchQuery.addEventListener('input', refreshFiltered);
    searchQuery.addEventListener('keydown', (event) => {
        if (event.key === 'Enter') {
            event.preventDefault();
            pagination.reset();
            loadUsers();
        }
    });
    refreshActivityBtn.addEventListener('click', loadRecentActivity);
    searchUsersBtn.addEventListener('click', () => {
        pagination.reset();
        loadUsers();
    });
    filterRole.addEventListener('change', () => {
        syncCardFromDropdowns();
        pagination.reset();
        selectedUserIds.clear();
        loadUsers();
    });
    filterActive.addEventListener('change', () => {
        syncCardFromDropdowns();
        pagination.reset();
        selectedUserIds.clear();
        loadUsers();
    });
    clearFilters.addEventListener('click', () => {
        searchQuery.value = '';
        filterRole.value = '';
        filterActive.value = '';
        setActiveFilterCard('all');
        pagination.reset();
        selectedUserIds.clear();
        loadUsers();
    });

    openAddUser.addEventListener('click', () => {
        resetModal();
        showModal();
    });

    if (closeModal) {
        closeModal.addEventListener('click', hideModal);
    }
    if (cancelUserForm) {
        cancelUserForm.addEventListener('click', hideModal);
    }
    window.addEventListener('click', (e) => {
        if (e.target === userModal) hideModal();
    });

    await Promise.all([
        loadUsers(),
        loadRecentActivity(),
    ]);
});
