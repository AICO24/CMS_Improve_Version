function getFrontendBasePath() {
    const currentPath = window.location.pathname || '';
    if (currentPath.includes('/frontend/')) {
        const prefix = currentPath.split('/frontend/')[0];
        return `${window.location.origin}${prefix}/frontend`;
    }

    if (currentPath.includes('/frontend')) {
        return `${window.location.origin}${currentPath.split('/frontend')[0]}/frontend`;
    }

    const prefix = currentPath.includes('/CMS') ? '/CMS' : '';
    return `${window.location.origin}${prefix}/frontend`;
}

function getAppOrigin() {
    const currentPath = window.location.pathname || '';
    let appBase = '';
    if (currentPath.includes('/frontend/')) {
        appBase = currentPath.split('/frontend/')[0];
    } else if (currentPath.includes('/frontend')) {
        appBase = currentPath.split('/frontend')[0];
    } else if (currentPath.includes('/CMS')) {
        appBase = '/CMS';
    }
    return `${window.location.origin}${appBase}`;
}
window.getAppOrigin = getAppOrigin;

const basePath = window.location.pathname.includes('/frontend/')
    ? window.location.pathname.split('/frontend/')[0]
    : window.location.pathname.split('/frontend')[0] || '';
const API_BASE = `${window.location.origin}${basePath}/backend/api`;

function getLoginRedirectUrl() {
    return `${getFrontendBasePath()}/auth/login.html`;
}

function getRoleDashboardPath(role) {
    const basePath = getFrontendBasePath();
    const roleName = String(role || '').toLowerCase();

    if (roleName === 'admin') {
        return `${basePath}/pages/dashboard_admin.html`;
    }

    if (roleName === 'staff') {
        return `${basePath}/pages/dashboard_staff.html`;
    }

    return `${basePath}/pages/dashboard_user.html`;
}

class ApiClient {
    constructor() {
        this.token = localStorage.getItem('jwt_token');
    }

    setToken(token) {
        this.token = token;
        if (token) {
            localStorage.setItem('jwt_token', token);
        } else {
            localStorage.removeItem('jwt_token');
        }
    }

    async request(endpoint, options = {}) {
        const isFormData = options.body instanceof FormData;
        const headers = {
            ...(options.headers || {}),
        };

        if (!isFormData) {
            headers['Content-Type'] = 'application/json';
        }

        if (this.token) {
            headers.Authorization = `Bearer ${this.token}`;
        }

        const response = await fetch(`${API_BASE}/${endpoint}`, {
            ...options,
            headers,
            body: isFormData ? options.body : options.body ? JSON.stringify(options.body) : undefined,
        });

        const data = await response.json().catch(() => ({}));

        if (!response.ok) {
            if (response.status === 401) {
                this.setToken(null);
                localStorage.removeItem('user_session');
                localStorage.removeItem('cemetery_session');
                window.location.href = getLoginRedirectUrl();
            }
            // AI Architecture Audit (2026-09-02), manual-test follow-up:
            // callers previously had no reliable way to tell a 429
            // (rate-limited) failure apart from any other error short of
            // string-matching the message text — status lets a caller like
            // lot-chat-assistant.js's isRateLimitError() check this
            // directly instead.
            const requestError = new Error(data.error || 'Request failed');
            requestError.status = response.status;
            throw requestError;
        }

        return data;
    }

    async login(username, password, role = null, rememberMe = false) {
        // allow calling code to pass either an email or a username in the first argument
        const payload = {};
        if (username && username.includes('@')) payload.email = username;
        else payload.username = username;
        payload.password = password;
        if (role) payload.role = role;
        payload.remember_me = Boolean(rememberMe);

        const result = await this.request('auth/login', {
            method: 'POST',
            body: payload,
        });

        if (result.token) {
            this.setToken(result.token);
        }

        // Normalize role value to 'admin' or 'staff' when possible
        if (result && result.user && result.user.role) {
            const r = String(result.user.role).toLowerCase();
            if (r.includes('admin')) result.user.role = 'admin';
            else if (r.includes('staff')) result.user.role = 'staff';
            else result.user.role = r;
        }

        return result;
    }

    async register(userData) {
        return await this.request('auth/register', {
            method: 'POST',
            body: userData,
        });
    }

    async forgotPassword(email) {
        return await this.request('auth/forgot-password', {
            method: 'POST',
            body: { email },
        });
    }

    async verifyResetCode(email, code) {
        return await this.request('auth/verify-reset-code', {
            method: 'POST',
            body: { email, code },
        });
    }

    async resetPassword(email, code, password, confirmPassword) {
        return await this.request('auth/reset-password', {
            method: 'POST',
            body: { email, code, password, confirm_password: confirmPassword },
        });
    }

    async getMe() {
        const result = await this.request('auth/me', { method: 'GET' });
        if (result && result.role) {
            const r = String(result.role).toLowerCase();
            if (r.includes('admin')) result.role = 'admin';
            else if (r.includes('staff')) result.role = 'staff';
            else result.role = r;
        }
        return result;
    }

    logout() {
        this.setToken(null);
        localStorage.removeItem('user_session');
        localStorage.removeItem('cemetery_session');
        window.location.href = getLoginRedirectUrl();
    }
}

const api = new ApiClient();

// Shared role-based access control: derived dynamically from centralized ROUTE_CONFIG
// (navigation-config.js). A static fallback dictionary is preserved for environments
// where navigation-config.js is not yet loaded, ensuring zero regressions.
const PAGE_ROLE_ACCESS = (typeof window !== 'undefined' && window.CMS_NAVIGATION && typeof window.CMS_NAVIGATION.buildPageRoleAccess === 'function')
    ? window.CMS_NAVIGATION.buildPageRoleAccess()
    : {
        'dashboard_admin.html': ['admin'],
        'dashboard_staff.html': ['staff'],
        'dashboard_user.html': ['user'],
        'book-a-service.html': ['admin', 'staff', 'user'],
        'booking-assistant.html': ['admin', 'staff', 'user'],
        'my-bookings.html': ['admin', 'staff', 'user'],
        'lot-management.html': ['admin', 'staff'],
        'burial-scheduling.html': ['admin', 'staff'],
        'manage-reservations.html': ['admin', 'staff'],
        'cremation-management.html': ['admin'],
        'manage-cremations.html': ['admin', 'staff'],
        'relocation-management.html': ['admin'],
        'expiration-monitoring.html': ['admin'],
        'decedent-records.html': ['admin', 'staff'],
        'payments.html': ['admin', 'staff', 'user'],
        'reports.html': ['admin'],
        'forecast.html': ['admin'],
        'user-management.html': ['admin'],
        'audit.html': ['admin'],
        'ai.html': ['admin'],
        'exceptions.html': ['admin', 'staff'],
        'reserve-burial-slot.html': ['user'],
        'my-reservations.html': ['user'],
        'reserve-cremation.html': ['user'],
        'my-cremations.html': ['user'],
        'payment-history.html': ['user'],
        'my-records.html': ['user'],
        'notifications.html': ['admin', 'staff', 'user'],
        'profile.html': ['admin', 'staff', 'user'],
        'settings.html': ['admin', 'staff', 'user'],
    };

// Dynamic getter to always check live CMS_NAVIGATION if loaded in the DOM
function getRouteAllowedRoles(pageFileName) {
    if (typeof window !== 'undefined' && window.CMS_NAVIGATION && typeof window.CMS_NAVIGATION.getRouteMetadata === 'function') {
        const meta = window.CMS_NAVIGATION.getRouteMetadata(pageFileName);
        if (meta && Array.isArray(meta.allowedRoles)) {
            return meta.allowedRoles;
        }
    }
    return PAGE_ROLE_ACCESS[pageFileName] || null;
}

const ROLE_LABELS = { admin: 'Administrator', staff: 'Staff', user: 'User' };

function getRoleLabel(role) {
    return ROLE_LABELS[String(role || '').toLowerCase()] || 'User';
}

function getPageFileName(href) {
    try {
        return new URL(href, window.location.origin).pathname.split('/').pop();
    } catch {
        return href.split('?')[0].split('#')[0].split('/').pop();
    }
}

// Removes/hides sidebar links the current role isn't allowed to open, so a
// page shared across roles (e.g. payments.html) never shows nav items (like
// User Management or Audit Logs) that role can't actually access. This is
// the default for every protected page.
// Shared admin/staff pages ship a single hardcoded Dashboard link
// (dashboard_admin.html). For a staff-verified role that would otherwise get
// stripped by the removal loop below (PAGE_ROLE_ACCESS restricts it to
// admin), silently dropping the Dashboard item entirely. Rewrite it to the
// current server-verified role's own dashboard first, so it survives
// filtering — navigation destination only, not a security check (F2 fix).
const ROLE_DASHBOARD_HREFS = { admin: 'dashboard_admin.html', staff: 'dashboard_staff.html', user: 'dashboard_user.html' };

function filterSidebarByRole(role) {
    const roleName = String(role || '').toLowerCase();
    const roleDashboard = ROLE_DASHBOARD_HREFS[roleName];
    if (roleDashboard) {
        const dashboardLink = document.querySelector(
            '.sidebar .nav-item[href="dashboard_admin.html"], .sidebar .nav-item[href="dashboard_staff.html"], .sidebar .nav-item[href="dashboard_user.html"]'
        );
        if (dashboardLink) {
            dashboardLink.setAttribute('href', roleDashboard);
        }
    }
    document.querySelectorAll('.sidebar .nav-item[href]').forEach((link) => {
        const href = link.getAttribute('href');
        if (!href) return;
        const allowedRoles = getRouteAllowedRoles(getPageFileName(href));
        if (allowedRoles && !allowedRoles.includes(roleName)) {
            link.remove();
        }
    });
    // A group whose every item just got removed above would otherwise leave
    // a header with an empty body — strip those too (sidebar audit, Batch 1).
    document.querySelectorAll('.sidebar .nav-group').forEach((group) => {
        if (!group.querySelector('.nav-item[href]')) {
            group.remove();
        }
    });
}

// A handful of pages are opened by every role but ship only ONE hardcoded
// sidebar in their static HTML, written from a single role's perspective
// (payments.html ships admin's; notifications/profile/settings.html ship
// user's). filterSidebarByRole() above can only ever subtract links from
// whatever shipped, so a role that didn't match the hardcoded list ended
// up with a near-empty or flat-out wrong sidebar — e.g. an admin or staff
// user clicking the notification bell landed on notifications.html and
// saw most of their normal sidebar missing, because it started from the
// user-role list. For exactly these pages, rebuild the sidebar instead of
// filtering it. Every other page (single-role pages, and admin/staff
// pages that already carry their own full nav list, e.g. ai.html) keeps
// the existing filterSidebarByRole behavior untouched.
const PAGES_NEEDING_SIDEBAR_REBUILD = ['payments.html', 'notifications.html', 'profile.html', 'settings.html'];

// Canonical sidebar structure, one per role — matches the grouped
// architecture established in Batches 1-4 (Dashboard as a bare top-level
// item, then role-appropriate Operations/Records/Finance/AI & Automation/
// Reports/System groups). Each entry is either `{ item: [href, icon, label] }`
// for a bare top-level link (Dashboard) or `{ group: label, items: [...] }`
// for an accordion group — no group is ever listed with an empty `items`
// array, so renderSidebarForRole() never has to filter anything out.
const ROLE_SIDEBAR_LINKS = {
    admin: [
        { item: ['dashboard_admin.html', 'fa-gauge-high', 'Dashboard'] },
        { group: 'Operations', items: [
            ['book-a-service.html', 'fa-handshake', 'Book a Service'],
            ['booking-assistant.html', 'fa-robot', 'Booking Assistant'],
            ['manage-bookings.html', 'fa-calendar-check', 'Manage Bookings'],
            ['lot-management.html', 'fa-map-location-dot', 'Lot Management'],
        ] },
        { group: 'Records', items: [
            ['decedent-records.html', 'fa-folder-open', 'Decedent Records'],
            ['cremation-management.html', 'fa-fire', 'Cremation Management'],
            ['relocation-management.html', 'fa-truck-moving', 'Relocation Management'],
            ['expiration-monitoring.html', 'fa-hourglass-half', 'Expiration Monitoring'],
        ] },
        { group: 'Finance', items: [
            ['payments.html', 'fa-credit-card', 'Payments'],
        ] },
        { group: 'AI & Automation', items: [
            ['ai.html', 'fa-robot', 'AI Configuration'],
            ['forecast.html', 'fa-chart-line', 'Capacity Forecast'],
            ['exceptions.html', 'fa-triangle-exclamation', 'Exceptions'],
        ] },
        { group: 'Reports', items: [
            ['reports.html', 'fa-chart-column', 'Reports'],
        ] },
        { group: 'System', items: [
            ['user-management.html', 'fa-users', 'User Management'],
            ['settings.html', 'fa-gear', 'Settings'],
            ['audit.html', 'fa-clipboard-list', 'Audit Logs'],
            ['profile.html', 'fa-id-card', 'Profile'],
        ] },
    ],
    staff: [
        { item: ['dashboard_staff.html', 'fa-gauge-high', 'Dashboard'] },
        { group: 'Operations', items: [
            ['book-a-service.html', 'fa-handshake', 'Book a Service'],
            ['booking-assistant.html', 'fa-robot', 'Booking Assistant'],
            ['manage-bookings.html', 'fa-calendar-check', 'Manage Bookings'],
            ['manage-reservations.html', 'fa-calendar-check', 'Manage Reservations'],
            ['manage-cremations.html', 'fa-calendar-check', 'Manage Cremations'],
        ] },
        { group: 'Cemetery Management', items: [
            ['lot-management.html', 'fa-map-location-dot', 'Lot Management'],
            ['cremation-management.html', 'fa-fire', 'Columbarium Management'],
        ] },
        { group: 'Records', items: [
            ['decedent-records.html', 'fa-folder-open', 'Decedent Records'],
        ] },
        { group: 'Finance', items: [
            ['payments.html', 'fa-credit-card', 'Payments'],
        ] },
        { group: 'System', items: [
            ['exceptions.html', 'fa-triangle-exclamation', 'System Exceptions'],
        ] },
        { group: 'Account', items: [
            ['profile.html', 'fa-id-card', 'Profile'],
            ['settings.html', 'fa-gear', 'Settings'],
        ] },
    ],
    user: [
        { item: ['dashboard_user.html', 'fa-gauge-high', 'Dashboard'] },
        { group: 'Services', items: [
            ['book-a-service.html', 'fa-handshake', 'Book a Service'],
            ['booking-assistant.html', 'fa-robot', 'Booking Assistant'],
        ] },
        { group: 'Records', items: [
            ['my-bookings.html', 'fa-calendar-check', 'My Bookings'],
            ['my-records.html', 'fa-folder-open', 'My Records'],
        ] },
        { group: 'Finance', items: [
            ['payments.html', 'fa-credit-card', 'Payments'],
            ['payment-history.html', 'fa-receipt', 'Payment History'],
        ] },
        { group: 'Account', items: [
            ['profile.html', 'fa-id-card', 'Profile'],
            ['settings.html', 'fa-gear', 'Settings'],
        ] },
    ],
};

function renderSidebarForRole(role) {
    const nav = document.querySelector('.sidebar .sidebar-nav');
    if (!nav) return;

    // Use centralized CMS_NAVIGATION rendering engine if available
    if (typeof window.CMS_NAVIGATION !== 'undefined' && typeof window.CMS_NAVIGATION.renderSidebar === 'function') {
        window.CMS_NAVIGATION.renderSidebar(nav, role);
        return;
    }

    const entries = ROLE_SIDEBAR_LINKS[String(role || '').toLowerCase()];
    if (!entries) return;

    const currentPage = window.location.pathname.split('/').pop();
    const renderItem = ([href, icon, label]) => {
        const isActive = href === currentPage;
        return `<a href="${href}" class="nav-item${isActive ? ' active' : ''}"><i class="fas ${icon} icon"></i> <span>${label}</span></a>`;
    };

    nav.innerHTML = entries.map((entry) => {
        if (entry.item) {
            return renderItem(entry.item);
        }
        return `<div class="nav-group"><button type="button" class="nav-group-header"><span>${entry.group}</span><i class="fas fa-chevron-down chev"></i></button><div class="nav-group-body">${entry.items.map(renderItem).join('')}</div></div>`;
    }).join('');

    // The old .nav-group-header elements (and any listeners on them) were
    // just destroyed along with the markup above — re-run the shared
    // accordion/active-group init (Batch 5) against the fresh nodes.
    if (typeof window.initSidebarNav === 'function') {
        window.initSidebarNav();
    }
}

function setUserDisplay(user) {
    const name = user.full_name || user.username || 'User';
    const label = getRoleLabel(user.role);
    ['userName', 'sidebarUserName'].forEach((id) => {
        const el = document.getElementById(id);
        if (el) el.textContent = name;
    });
    ['userRole', 'sidebarUserRole'].forEach((id) => {
        const el = document.getElementById(id);
        if (el) el.textContent = label;
    });
}

// Shared route guard. Call first thing in a protected page's DOMContentLoaded
// handler: `const user = await requireRole(['admin']); if (!user) return;`
// Role comes from api.getMe() (server-verified via the JWT), never from
// localStorage, which is client-editable and cannot be trusted for authorization.
async function requireRole(allowedRoles) {
    let user;
    try {
        user = await api.getMe();
    } catch (error) {
        window.location.href = getLoginRedirectUrl();
        return null;
    }

    if (!user || !user.user_id) {
        window.location.href = getLoginRedirectUrl();
        return null;
    }

    const roleName = String(user.role || '').toLowerCase();
    if (Array.isArray(allowedRoles) && allowedRoles.length && !allowedRoles.includes(roleName)) {
        window.location.href = getRoleDashboardPath(roleName);
        return null;
    }

    setUserDisplay(user);

    if (typeof window !== 'undefined' && window.CMS_NAVIGATION && typeof window.CMS_NAVIGATION.renderSidebar === 'function') {
        renderSidebarForRole(roleName);
    } else {
        filterSidebarByRole(roleName);
        const currentPage = window.location.pathname.split('/').pop();
        if (PAGES_NEEDING_SIDEBAR_REBUILD.includes(currentPage)) {
            renderSidebarForRole(roleName);
        }
    }
    document.querySelectorAll('.admin-only').forEach((el) => {
        if (roleName === 'admin') {
            el.style.display = 'flex';
            el.classList.remove('admin-only');
        } else {
            el.style.display = 'none';
        }
    });

    return user;
}

// Escape closes any open modal (Batch 6 accessibility). Each page already
// closes its modals via `element.style.display = 'none'` from its own
// close-button handler; this just triggers the same thing on Escape, so
// no per-page JS needs to change.
document.addEventListener('keydown', (e) => {
    if (e.key !== 'Escape') return;
    document.querySelectorAll('.modal').forEach((modal) => {
        const isOpen = modal.style.display === 'flex' || modal.style.display === 'block';
        if (isOpen) {
            modal.style.display = 'none';
        }
    });
});

// Elements marked role="button" (e.g. the notification icon, which is a
// <div> for layout reasons) don't get native Enter/Space activation the
// way a real <button> does. This dispatches a click for them so any
// existing click handler on that element still fires (Batch 6).
document.addEventListener('keydown', (e) => {
    if (e.key !== 'Enter' && e.key !== ' ') return;
    const target = e.target;
    if (target && target.matches && target.matches('[role="button"]')) {
        e.preventDefault();
        target.click();
    }
});

// Highlights the sidebar link matching the current page. This runs first
// (api.js loads, and registers this listener, before each page's own
// script); role-based visibility/redirects are handled afterward by
// requireRole(), which each protected page calls explicitly.
document.addEventListener('DOMContentLoaded', () => {
    const currentPage = window.location.pathname.split('/').pop();

    document.querySelectorAll('.sidebar .nav-item').forEach(link => {
        const href = link.getAttribute('href');
        if (!href) return;
        if (getPageFileName(href) === currentPage) {
            link.classList.add('active');
        }
    });
});

// Global safe no-op stub for deprecated floating AI widget to ensure no console errors
if (typeof window !== 'undefined' && typeof window.initAiAssistant !== 'function') {
    window.initAiAssistant = function() { return null; };
}
