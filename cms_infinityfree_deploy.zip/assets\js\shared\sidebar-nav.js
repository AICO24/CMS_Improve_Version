/*
  Grouped sidebar: single-open accordion + desktop manual icon-rail.
  Purely additive UI state — never touches .sidebar.collapsed or the
  hamburger checkbox, so that existing mechanism (dashboard.css 200-259,
  553-611) keeps working exactly as before, untouched by this file.

  Single-open accordion: opening one group closes any other open group,
  and the group containing the current page auto-opens on load (state is
  never hardcoded in HTML — computed here from the URL, same source of
  truth api.js's active-link highlighter already uses) so the sidebar
  never shows more than one expanded group's worth of items at once.

  Exposed as window.initSidebarNav (Batch 5) so pages whose sidebar is
  rebuilt at runtime (renderSidebarForRole() in api.js, for
  payments/notifications/profile/settings.html) can re-run
  initialization after replacing .sidebar-nav's innerHTML — the old
  .nav-group-header elements (and any listeners on them) are destroyed
  along with the old markup, so re-attaching to the fresh elements each
  call is safe by construction. #railToggleBtn lives in .sidebar-header,
  outside .sidebar-nav, so it's never replaced by a rebuild — its
  listener is guarded by a data-attribute flag so repeated init calls
  never attach a second one to the same persistent button.
*/
(function () {
    function initSidebarNav() {
        var sidebar = document.querySelector('.sidebar');
        if (!sidebar) return;

        var groups = Array.prototype.slice.call(sidebar.querySelectorAll('.nav-group'));

        function closeOthers(exceptGroup) {
            groups.forEach(function (group) {
                if (group !== exceptGroup) {
                    group.classList.remove('open');
                }
            });
        }

        // Group expand/collapse — single-open accordion. Guarded per-header
        // so calling initSidebarNav() again on unchanged markup never attaches
        // a second listener to the same header.
        groups.forEach(function (group) {
            var header = group.querySelector('.nav-group-header');
            if (!header || header.dataset.sidebarNavBound === '1') return;
            header.dataset.sidebarNavBound = '1';
            header.addEventListener('click', function () {
                var willOpen = !group.classList.contains('open');
                closeOthers(group);
                group.classList.toggle('open', willOpen);
            });
        });

        // Determine active page and parent group based on current URL / page
        var currentPage = (window.location.pathname.split('/').pop() || '').split('?')[0].split('#')[0];
        var isDashboard = !currentPage || currentPage === 'index.html' || currentPage.indexOf('dashboard_') === 0;

        if (isDashboard) {
            // Rule 1: On all dashboard pages (Admin, Staff, User), ALL groups must be closed
            closeOthers(null);
        } else {
            // Rule 2: On module pages, automatically open ONLY the parent group of the current page
            var activeGroup = groups.find(function (group) {
                return Array.prototype.some.call(group.querySelectorAll('.nav-item[href]'), function (link) {
                    var href = link.getAttribute('href');
                    if (!href) return false;
                    var linkPage = href.split('?')[0].split('#')[0].split('/').pop();
                    return linkPage === currentPage;
                });
            });
            if (activeGroup) {
                closeOthers(activeGroup);
                activeGroup.classList.add('open');
            } else {
                closeOthers(null);
            }
        }

        // Manual icon-rail (desktop only — CSS hides the button below
        // 1025px). Persists across sidebar rebuilds, so guard it the same
        // way as the group headers above.
        var railBtn = document.getElementById('railToggleBtn');
        if (!railBtn || railBtn.dataset.sidebarNavBound === '1') return;
        railBtn.dataset.sidebarNavBound = '1';

        var stored = null;
        try {
            stored = localStorage.getItem('cms-sidebar-rail');
        } catch (e) {
            /* storage unavailable — falls through to default expanded state */
        }
        if (stored === '1') {
            sidebar.classList.add('rail-manual');
        }

        railBtn.addEventListener('click', function () {
            var isRail = sidebar.classList.toggle('rail-manual');
            try {
                localStorage.setItem('cms-sidebar-rail', isRail ? '1' : '0');
            } catch (e) {
                /* storage unavailable — toggle still applies for this page view */
            }
        });
    }

    window.initSidebarNav = initSidebarNav;

    // Listen to DOMContentLoaded and browser Back/Forward navigation
    document.addEventListener('DOMContentLoaded', initSidebarNav);
    window.addEventListener('popstate', initSidebarNav);
})();
